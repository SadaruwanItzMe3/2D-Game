# Flame Runner — 2D Game Remastered

A browser runner built with HTML5 canvas, CSS3 and vanilla JavaScript. Jump over the flames and reach 100 points.

## Run
Static files only. Either open `index.html`, or serve the folder (`python3 -m http.server`) and visit http://localhost:8000.
Deploy by uploading the folder to GitHub Pages, Netlify, Vercel or any static host.

## Controls
| Action | Keyboard | Touch |
|---|---|---|
| Jump | Space / ↑ / W | Tap the game |
| Pause | P / Esc | ⏸ button |
| Mute | M | 🔊 button |

## Difficulty
| Level | Speed | Lives | Flame spacing |
|---|---|---|---|
| Casual | 300 | 5 | wide |
| Standard | 420 | 3 | medium |
| Hardcore | 560 | 2 | tight |
| Advanced | 720 | 1 | tightest |
Speed also rises slowly during a run. A hit costs a life and gives 1.5 s of invincibility.

## Files
`index.html` (all screens) · `style.css` · `game.js` (engine, UI, audio, storage) · `assets/` (original sprites, backgrounds, flame, star, audio).

## Saved data
Best score per difficulty, volumes, mute and last selections use `localStorage`. Invalid or blocked storage falls back to defaults.
