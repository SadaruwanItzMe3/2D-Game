(() => {
'use strict';
// ===== Config =====
const W = 1280, H = 640, GROUND = 560, WIN_SCORE = 100, JUMP_V = -1050, GRAVITY = 2800;
const CHARS = {
  male:   { dir: 'player1', run: 15, jump: 15, dead: 15, h: 250 },
  female: { dir: 'player2', run: 20, jump: 30, dead: 30, h: 250 }
};
// speed (px/s), gap = speed*(gMin + rand*gRand)+180 (smaller = more flames), lives
const DIFFS = {
  casual:   { speed: 300, gMin: 1.2,  gRand: .9, lives: 5, desc: 'Slow and forgiving. 5 lives, wide gaps between flames.' },
  standard: { speed: 420, gMin: .95,  gRand: .8, lives: 3, desc: 'The classic run. 3 lives, steady speed.' },
  hardcore: { speed: 560, gMin: .85,  gRand: .6, lives: 2, desc: 'Fast and tiring. 2 lives, flames come quickly.' },
  advanced: { speed: 720, gMin: .75,  gRand: .5, lives: 1, desc: 'For skilled players. One life, top speed.' }
};
const RANKS = [[80,'best'],[60,'super'],[40,'wow'],[20,'nice'],[10,'normal'],[0,'keep trying']];
const $ = id => document.getElementById(id);
const cv = $('game'), ctx = cv.getContext('2d');

// ===== Safe storage (validated; works if localStorage is blocked) =====
const store = {
  get(k, d, ok) { try { const v = JSON.parse(localStorage.getItem('fr-' + k)); return ok(v) ? v : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('fr-' + k, JSON.stringify(v)); } catch { /* ignore */ } }
};
const vol = v => typeof v === 'number' && v >= 0 && v <= 1;
const sel = {
  char: store.get('char', 'male', v => v in CHARS),
  bg: store.get('bg', 'bg3', v => ['bg1','bg2','bg3'].includes(v)),
  diff: store.get('diff', 'standard', v => v in DIFFS)
};
const cfg = { music: store.get('music', .6, vol), sfx: store.get('sfx', .8, vol), muted: store.get('muted', false, v => typeof v === 'boolean') };

// ===== Audio (created once; started only after a user gesture) =====
const mk = n => new Audio('assets/audio/' + n + '.mp3');
const sRun = mk('run'), sJump = mk('jump'), sDead = mk('dead'), sWin = mk('win');
sRun.loop = true;
let ac = null;
function applyAudio() {
  sRun.volume = cfg.muted ? 0 : cfg.music * .8;
  [sJump, sDead, sWin].forEach(a => a.volume = cfg.muted ? 0 : cfg.sfx);
  $('muteBtn').textContent = cfg.muted ? '🔇' : '🔊';
  $('vMusic').value = cfg.music * 100; $('vSfx').value = cfg.sfx * 100; $('vMute').checked = cfg.muted;
}
const sfx = a => { if (cfg.muted) return; a.currentTime = 0; a.play().catch(() => {}); };
function tick() { // tiny UI click via WebAudio (no extra asset needed)
  if (cfg.muted) return;
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    const o = ac.createOscillator(), g = ac.createGain();
    o.frequency.value = 660; g.gain.value = .08 * cfg.sfx;
    o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + .05);
  } catch { /* audio unavailable */ }
}
const startRun = () => { if (!cfg.muted) sRun.play().catch(() => {}); };

// ===== Assets =====
const loadImg = src => new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = src; });
const cache = {};
async function frames(char, anim, n) {
  const key = char + anim; if (cache[key]) return cache[key];
  const list = []; for (let i = 1; i <= n; i++) list.push(loadImg(`assets/${CHARS[char].dir}/${anim} (${i}).png`));
  return (cache[key] = await Promise.all(list));
}
let flameImg = null, bgImg = null;

// ===== State =====
let S = null, raf = 0, last = 0, screenId = 'menu';
const best = () => store.get('best-' + sel.diff, 0, v => Number.isInteger(v) && v >= 0);
function show(id) {
  screenId = id;
  document.querySelectorAll('.screen').forEach(s => s.classList.toggle('show', s.id === id));
  document.body.classList.toggle('playing', id === 'none');
}
const hearts = () => { $('lives').textContent = '♥'.repeat(S.lives); };

async function startGame() {
  if (S && S.loading) return;
  const c = CHARS[sel.char], d = DIFFS[sel.diff];
  $('startBtn').textContent = 'Loading…';
  const tmp = { loading: true }; S = tmp;
  const [run, jump, dead, fl, bg] = await Promise.all([
    frames(sel.char, 'Run', c.run), frames(sel.char, 'Jump', c.jump), frames(sel.char, 'Dead', c.dead),
    flameImg || loadImg('assets/icons/flame.gif'), loadImg(`assets/bg/${sel.bg}.jpg`)
  ]);
  $('startBtn').textContent = 'Start';
  if (S !== tmp) return;
  flameImg = fl; bgImg = bg;
  S = { run, jump, dead, d, t: 0, bgx: 0, y: 0, vy: 0, air: false, airT: 0, score: 0, scoreT: 0,
        flames: [], nextGap: 700, state: 'play', deadT: 0, anim: 0, lives: d.lives, inv: 0 };
  $('best').textContent = best() ? 'Best ' + best() : '';
  $('score').textContent = 0; hearts();
  show('none'); sRun.currentTime = 0; startRun();
  last = performance.now(); cancelAnimationFrame(raf); raf = requestAnimationFrame(loop);
}
function jump() {
  if (S && S.state === 'play' && !S.air) { S.vy = JUMP_V; S.air = true; S.airT = 0; sfx(sJump); }
}
function pause(on) {
  if (!S || !S.state) return;
  if (on && S.state === 'play') { S.state = 'pause'; sRun.pause(); show('pause'); }
  else if (!on && S.state === 'pause') { S.state = 'play'; show('none'); startRun(); last = performance.now(); cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); }
}
function finish(win) {
  S.state = 'over'; sRun.pause(); cancelAnimationFrame(raf);
  const sc = S.score, isBest = sc > best();
  if (isBest) store.set('best-' + sel.diff, sc);
  $('overTitle').textContent = win ? 'YOU WIN!' : 'Game over';
  $('finalScore').textContent = sc;
  $('rank').textContent = win ? 'perfect run' : RANKS.find(r => sc >= r[0])[1];
  $('newBest').textContent = isBest && sc > 0 ? 'New best!' : '';
  const stars = [10,20,40,60,80].filter(n => sc >= n).length;
  document.querySelectorAll('.stars img').forEach((im, i) => im.classList.toggle('on', i < stars));
  show('over'); if (win) sfx(sWin);
}

// ===== Loop =====
function loop(now) {
  const dt = Math.min(.05, (now - last) / 1000); last = now; // clamp after tab switches
  update(dt); draw();
  if (S.state === 'play' || S.state === 'dead') raf = requestAnimationFrame(loop);
}
function update(dt) {
  const s = S;
  if (s.state === 'dead') { s.deadT += dt; if (s.deadT > 1.1) finish(false); return; }
  s.t += dt; s.anim += dt; s.inv = Math.max(0, s.inv - dt);
  const speed = s.d.speed * (1 + Math.min(.35, s.t * .004)); // difficulty ramps up over time
  s.bgx = (s.bgx + speed * .6 * dt) % W;
  if (s.air) { s.airT += dt; s.vy += GRAVITY * dt; s.y += s.vy * dt; if (s.y >= 0) { s.y = 0; s.vy = 0; s.air = false; } }

  // spawn: gaps scale with speed so every flame is always jumpable
  const edge = s.flames.length ? s.flames[s.flames.length - 1].x : 0;
  if (edge < W + 200 - s.nextGap) {
    s.flames.push({ x: Math.max(W + 100, edge + s.nextGap) });
    s.nextGap = speed * (s.d.gMin + Math.random() * s.d.gRand) + 180;
  }
  for (const f of s.flames) f.x -= speed * dt;
  while (s.flames.length && s.flames[0].x < -150) s.flames.shift();

  // collision (slightly forgiving hitboxes); invincible briefly after a hit
  const ph = CHARS[sel.char].h, px = 200 + ph * .18, py = GROUND - s.y - ph * .78, pw = ph * .28, phh = ph * .72;
  if (s.inv <= 0) for (const f of s.flames) {
    const fx = f.x + 22, fy = GROUND - 150;
    if (px < fx + 40 && px + pw > fx && py < fy + 150 && py + phh > fy) {
      s.lives--; hearts(); f.x = -999; // consume the flame
      if (s.lives <= 0) { s.state = 'dead'; s.deadT = 0; sRun.pause(); sfx(sDead); }
      else { s.inv = 1.5; sfx(sDead); }
      break;
    }
  }
  s.scoreT += dt;
  if (s.scoreT >= .75) { s.scoreT -= .75; s.score++; $('score').textContent = s.score; if (s.score >= WIN_SCORE) finish(true); }
}
function draw() {
  const s = S;
  if (bgImg) { ctx.drawImage(bgImg, -s.bgx, 0, W, H); ctx.drawImage(bgImg, W - s.bgx, 0, W, H); }
  else { ctx.fillStyle = '#223'; ctx.fillRect(0, 0, W, H); }
  if (flameImg) for (const f of s.flames) ctx.drawImage(flameImg, f.x, GROUND - 160, 160 * 505 / 933, 160);
  let list, i;
  if (s.state === 'dead') { list = s.dead; i = Math.min(list.length - 1, Math.floor(s.deadT * 20)); }
  else if (s.air) { list = s.jump; i = Math.min(list.length - 1, Math.floor(s.airT / .75 * list.length)); }
  else { list = s.run; i = Math.floor(s.anim * 24) % list.length; }
  const im = list[i], h = CHARS[sel.char].h;
  if (im) {
    ctx.globalAlpha = s.inv > 0 && Math.floor(s.inv * 10) % 2 ? .35 : 1; // blink while invincible
    const w = h * im.width / im.height;
    ctx.drawImage(im, 200 - (w - h * .5) / 2, GROUND - h - s.y + 8, w, h);
    ctx.globalAlpha = 1;
  }
}

// ===== UI wiring (each listener attached once) =====
function syncSel() {
  document.querySelectorAll('.opts').forEach(g => g.querySelectorAll('.opt').forEach(o => {
    const on = o.dataset.v === sel[g.dataset.key]; o.classList.toggle('sel', on); o.setAttribute('aria-pressed', on);
  }));
  $('diffDesc').textContent = DIFFS[sel.diff].desc;
}
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => { tick(); show(b.dataset.go); }));
document.querySelectorAll('.opts').forEach(g => {
  g.addEventListener('click', e => {
    const b = e.target.closest('.opt'); if (!b) return;
    tick(); sel[g.dataset.key] = b.dataset.v; store.set(g.dataset.key, b.dataset.v); syncSel();
  });
  g.addEventListener('keydown', e => { // arrow keys move between options
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    const o = [...g.querySelectorAll('.opt')], i = o.indexOf(document.activeElement); if (i < 0) return;
    e.preventDefault(); const n = o[(i + (e.key === 'ArrowRight' ? 1 : o.length - 1)) % o.length]; n.focus(); n.click();
  });
});
$('startBtn').addEventListener('click', startGame);
$('againBtn').addEventListener('click', startGame);
$('menuBtn').addEventListener('click', () => { S = null; show('menu'); });
$('quitBtn').addEventListener('click', () => { S = null; cancelAnimationFrame(raf); sRun.pause(); show('menu'); });
$('resumeBtn').addEventListener('click', () => pause(false));
$('pauseBtn').addEventListener('click', e => { pause(true); e.currentTarget.blur(); });
$('muteBtn').addEventListener('click', e => { cfg.muted = !cfg.muted; store.set('muted', cfg.muted); applyAudio(); if (S && S.state === 'play') startRun(); e.currentTarget.blur(); });
$('vMusic').addEventListener('input', e => { cfg.music = e.target.value / 100; store.set('music', cfg.music); applyAudio(); });
$('vSfx').addEventListener('input', e => { cfg.sfx = e.target.value / 100; store.set('sfx', cfg.sfx); applyAudio(); });
$('vMute').addEventListener('change', e => { cfg.muted = e.target.checked; store.set('muted', cfg.muted); applyAudio(); });
cv.addEventListener('pointerdown', e => { e.preventDefault(); jump(); });
document.addEventListener('visibilitychange', () => document.hidden && pause(true));
addEventListener('blur', () => pause(true));
addEventListener('keydown', e => {
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
    if (S && S.state === 'play') { e.preventDefault(); if (!e.repeat) jump(); }
  } else if (e.code === 'KeyP' || e.code === 'Escape') { if (S) pause(S.state === 'play'); }
  else if (e.code === 'KeyM') $('muteBtn').click();
});
applyAudio(); syncSel();
})();
